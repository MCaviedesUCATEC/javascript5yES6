/*****************
 Parámetros
*****************/
//
//Número de cuadros
//
nCuadros=4;
//
//Tipos de figuras
//
nTipos=7;
//
//Tamaño del tablero
//
tableroAltura=16;
tableroAncho =10;
//
//Nivel
//
nivel=1;
//
//Velocidad
//
velocidad0=700;
velocidadK=60;
velocidad=velocidad0-velocidadK*nivel;
//
//Número de líneas
//
nLineas=0;
//
/*********************
  GLOBAL VARIABLES
**********************/
//
//Coordenadas actuales x,y
//
curX=1; curY=1;
//
//La última línea disponible
//
lineaLimite=tableroAltura-1;
//
//Serial N 
//
serialN=0;
//
//Banderas
//
tableroCargado=0;
pausaJuego=0;
inicioJuego=0;
finJuego=0;
//
//Timer
//
timerID=null;
//
// Imágenes
//
if (document.images) {
 Img0=new Image(); Img0.src='s0.gif';
 Img1=new Image(); Img1.src='s1.gif';
 Img2=new Image(); Img2.src='s2.gif';
 Img3=new Image(); Img3.src='s3.gif';
 Img4=new Image(); Img4.src='s4.gif';
 Img5=new Image(); Img5.src='s5.gif';
 Img6=new Image(); Img6.src='s6.gif';
 Img7=new Image(); Img7.src='s7.gif';
}
//
// ARREGLOS
//
//Creamos arreglos de 20x20 con 0
//
f=new Array();
for (i=0;i<20;i++) {
 f[i]=new Array();
 for (j=0;j<20;j++) {
   f[i][j]=0;
 }
}
//
xBorrar =new Array(0,0,0,0);     yBorrar =new Array(0,0,0,0);
//
//Desplazamiento dx, dy, dx_, dy_
//
dx=new Array(0,0,0,0); dy=new Array(0,0,0,0);
dx_=new Array(0,0,0,0); dy_=new Array(0,0,0,0);
//
//dxBank, dyBank 4?
//
dxBank=new Array(); dyBank=new Array();
dxBank[1]=new Array(0, 1,-1, 0);  dyBank[1]=new Array(0, 0, 0, 1);
dxBank[2]=new Array(0, 1,-1,-1);  dyBank[2]=new Array(0, 0, 0, 1);
dxBank[3]=new Array(0, 1,-1, 1);  dyBank[3]=new Array(0, 0, 0, 1);
dxBank[4]=new Array(0,-1, 1, 0);  dyBank[4]=new Array(0, 0, 1, 1);
dxBank[5]=new Array(0, 1,-1, 0);  dyBank[5]=new Array(0, 0, 1, 1);
dxBank[6]=new Array(0, 1,-1,-2);  dyBank[6]=new Array(0, 0, 0, 0);
dxBank[7]=new Array(0, 1, 1, 0);  dyBank[7]=new Array(0, 0, 1, 1);
//
// FUNCTIONS
//
function reiniciaJuego() {
  //
  //Descripción: Limpia las variables a cero
  //Parámetros: ninguno
  //Variables locales: i,j
  //Variables globales: tableroAltura, tableroAncho, f, inicioJuego,
  //                    pausaJuego, nLineas, serialN
  //Salida: f,inicioJuego, pausaJuego, nLineas, serialN
  //
  for (var i = 0; i < tableroAltura; i++) {
    for (var j = 0; j < tableroAncho; j++) {
      f[i][j] = 0;
      if (tableroCargado) {
        //cargamos el recuadro blanco
        eval("top.document.s"+i+"_"+j+".src='s0.gif'");
      }
    }  
  }
  //
  //Inicializa banderas
  //
  inicioJuego = 0;
  pausaJuego = 0;
  nLineas = 0;
  serialN = 0;
  //
  // Ultima línea disponible
  //
  lineaLimite = tableroAltura-1;
  //
  //Numero de líneas
  //
  if (tableroCargado) {
    self.document.form1.lineas.value=nLineas;
  }
  console.log("reiniciaJuego");
}

function iniciarJuego() {
  //
  //Descripción: Inicia el juego
  //Parámetros: ninguno
  //Variables locales: 
  //Variables globales: finJuego, inicioJuego, tableroCargado, pausaJuego, velocidad
  //Funciones: reanudarJuego(), obtenerPieza(), dibujarPieza()
  //Salida: 
  //
  //Terminar el juego
  //
  console.log("iniciarJuego");
  if (finJuego) {
    top.history.back();
    finJuego = 0;
  }
  //
  //foco()
  //
  top.focus();
  //
  //Ya se había seleccionado "inicio"
  //
  if (inicioJuego) {
    if (!tableroCargado) {
      return
    }
    if (pausaJuego) {
      reanudarJuego();
    }
    return;
  }
  //
  //Obtiene la pieza
  //
  obtenerPieza();
  //
  //Dibujar la pieza
  //
  dibujarPieza();
  //
  //Enciende la bandera de inicio
  //
  inicioJuego=1;
  //
  //Apaga la bandera de pausa
  //
  pausaJuego=0;
  //
  //Recupera el numero de líneas
  //
  self.document.form1.lineas.value = nLineas;
  //
  //Inicia el setTimeout
  //
  timerID = setTimeout("jugar()",velocidad);
}

function pausarJuego() {
  //
  //Descripción: pausa el juego
  //Parámetros: ninguno
  //Variables locales: 
  //Variables globales: 
  //Salida: 
  //
  if (tableroCargado && inicioJuego) {
    if (pausaJuego) {
      reanudarJuego(); 
      return;
    }
    //
    //Borra el timeout
    //
    clearTimeout(timerID);
    //
    //Enciende la bandera de pausa
    //
    pausaJuego=1;
    //
    //Focus
    //
    top.focus();
  }
}

function reanudarJuego() {
  //
  //Descripción: reanuda el juego
  //Parámetros: ninguno
  //Variables locales: 
  //Variables globales: tableroCargado, inicioJuego, pausaJuego
  //Salida: 
  //
  if (tableroCargado && inicioJuego && pausaJuego) {
    //
    //Reanuda juego
    //
    jugar();
    //
    //Borra la bandera de pausa
    //
    pausaJuego=0;
    top.focus();
  }
}

function jugar() {
  //
  //Descripción: ejecuta el juego
  //Parámetros: ninguno
  //Variables locales: activeL_, activeU_, activeR_, activeD_=0;
  //Variables globales: timerID, velocidad, lineaLimite
  //Funciones: moverAbajo(), jugar(), redibujarMatrix(), removerLineas(), obtenerPieza()
  //Salida: 
  //
  console.log("jugar");
  if (moverAbajo()) {
    timerID=setTimeout("jugar()",velocidad);
    return;
  } else {
    redibujarMatrix();
    removerLineas();
    if (lineaLimite>0 && obtenerPieza()) {
      timerID=setTimeout("jugar()",velocidad);
      return;
    } else {
      activeL_=0; activeU_=0;
      activeR_=0; activeD_=0;
      if (confirm("Fin del juego\n\n¿Volver a intentarlo?")) {
        inicio();
      } else {
        if (finJuego) {
          inicio();
        } else {
          self.close();
        }
      }
    }
  }
}

function redibujarMatrix() {
  //
  //Descripción: rellena la matrix
  //Parámetros: ninguno
  //Variables locales: 
  //Variables globales: 
  //Salida: 
  //
  console.log("redibujarMatrix");
  for (var k=0;k<nCuadros;k++) {
    //
    //Próximo cuadro
    //
    X=curX+dx[k];
    Y=curY+dy[k];
    //
    //Verifica valores en frontera
    //
    if (0<=Y && Y<tableroAltura && 0<=X && X<tableroAncho) {
      //
      //Rellena cuadro
      //
      f[Y][X]=piezaActual;
      //
      //Línea límite
      //
      if (Y<lineaLimite) lineaLimite=Y;
    }
  }
  top.focus();
}

function removerLineas() {
  //
  //Descripción: remueve líneas
  //Parámetros: ninguno
  //Variables locales: i,j, bandera,k, 
  //Variables globales: tableroAltura, tableroAncho, f, nLineas, lineaLimite, nivel
  //Salida: 
  //

}

function recuperarNivel() {
  //
  //Descripción: recuperar nivel
  //Parámetros: ninguno
  //Variables locales: 
  //Variables globales: 
  //Salida: nivel, velocidad
  //

}

function dibujarPieza() {
  //
  //Descripción: Dibuja pieza
  //Parámetros: -Ninguno-
  //Variables locales: k, X, Y
  //Variables globales: nCuadros, curX, curY, dx, dy, piezaActual
  //
  var k, X, Y;
  //
  //Verifica si está cargado el tablero
  //
  if (document.images && tableroCargado) {
    //
    //Recorrer el arreglo
    //
    console.log("dibujarPieza",piezaActual);
    for(k=0; k<nCuadros;k++){
      //
      //Recupermos valores
      //
      X = curX + dx[k];
      Y = curY + dy[k];
      //
      //Verifica coordenadas
      //
      if (Y>=0 && Y<tableroAltura && X>=0 && X<tableroAncho && f[Y][X]!=-piezaActual) {
        //
        //dibujar pieza
        //
        eval("self.document.s"+Y+"_"+X+".src=Img"+piezaActual+".src");
        //
        //Almacenamos el valor de la pieza
        //
        f[Y][X]=-piezaActual;
      }
      //
      //Regresa valor a borrar
      //
      X = xBorrar[k];
      Y = yBorrar[k];
      //
      //Si el valor anterior es cero, lo "borramos"
      //
      if (f[Y][X]==0) {
        eval("self.document.s"+Y+"_"+X+".src=Img0.src");
      }
    }
  }
}

function borrarPieza() {
  //
  //Descripción: remueve líneas
  //Parámetros: ninguno
  //Variables locales: 
  //Variables globales: 
  //Salida: 
  //
  console.log("borrarPieza");
  if (document.images && tableroCargado) {
    for (var k=0;k<nCuadros;k++) {
      X=curX+dx[k];
      Y=curY+dy[k];
      if (0<=Y && Y<tableroAltura && 0<=X && X<tableroAncho) {
        xBorrar[k]=X;
        yBorrar[k]=Y;
        f[Y][X]=0;
      }
    }
  }
}

function validarPieza(X,Y) {
  //
  // Descripción: validar una pieza
  //parámetros: coordenas x,y
  //variable globales: nCuadros,dx_,dy_
  //variables locales: miX, miY, k
  //regresa: 1 si no se "sale" del tablero
  //         0 si se "sale" del tablero
  //
  console.log("validarMatrix");
  for (var k=0;k<nCuadros;k++) {
    //Suma la distancia
    miX=X+dx_[k];
    miY=Y+dy_[k];
    //
    //Se sale por la izquierda o arriba
    if (miX<0 || miX>=tableroAncho || miY>=tableroAltura) return 0;
    //Se sale por la derecha o abajo
    if (miY>-1 && f[miY][miX]>0) return 0;
  }
  //
  //Si no se sale, regresa 1
  //
  return 1;

}

function moverIzquierda() {
  //
  //Descripción: mueve izquierda
  //Parámetros: ninguno
  //Variables locales: 
  //Variables globales: 
  //Salida: 
  //

}

function moverDerecha() {
  //
  //Descripción: mueve pieza a la derecha
  //Parámetros: -
  //Variables locales: k
  //Variables globales: nCuadros, dx, dy, dx_, dy_
  //Salida: 
  //

}

function rotar() {
  //
  //Descripción: rotar
  //Parámetros: ninguno
  //Variables locales: 
  //Variables globales: nCuadros, dx, dy, dx_, dy_
  //Salida: 
  //

}

function moverAbajo() {
  //
  //Descripción: mover abajo
  //Parámetros: ninguno
  //Variables locales: k
  //Variables globales: nCuadros, dx_[k], dx[k], dy_[k], dy[k], curX, curY
  //Salida: 
  //
  console.log("moverAbajo",curY);
  var k;
  for (k=0;k<nCuadros;k++) {
    dx_[k]=dx[k]; 
    dy_[k]=dy[k];
  }
  if (validarPieza(curX,curY+1)) {
    borrarPieza(); 
    curY++; 
    dibujarPieza(); 
    return 1; 
  }
  return 0;
}

function bajar() {
  //
  //Descripción: bajar la pieza
  //Parámetros: ninguno
  //Variables locales: k
  //Variables globales: nCuadros, dx_[k], dx[k], dy_[k], dy[k], curX, curY, timeID
  //Salida: 
  //
  var k;

}

function obtenerPieza(N) {
  //
  //Descripción: Calcula la pieza actual
  //Parámetro: N, puede estar vacío y se calcula aleatoriamente
  //Variables locales: piezaActual, k
  //Variables globales: nTipos, curX, curY, nSqueres, dx,dy,dxBank, dyBank
  //Llama funciones: pieceFits, dibujarPieza
  //
  var k;
  piezaActual = (obtenerPieza.arguments.length==0)?1+Math.floor(nTipos*Math.random()):N;
  console.log("obtenerPieza",piezaActual);
  //
  curX = 5;
  curY = 0;
  //
  //Vaciamos los datos de la figura
  for (var k = 0; k < nCuadros; k++) {
    dx[k]=dxBank[piezaActual][k];
    dy[k]=dyBank[piezaActual][k];
  }
  //
  //Igualar los arreglos de trabajo
  //
  for (var k = 0; k < nCuadros; k++) {
    dx_[k]=dx[k];
    dy_[k]=dy[k];
  }
  //
  //Valida pieza
  //
  if (validarPieza(curX,curY)) {
    dibujarPieza();
    return 1;
  }
  return 0;
}
/*****************************
 Proceso del click del ratón
******************************/
function obtenerMinMax() {
  //
  //Llamada desde: Obtener máximo y mínimo
  //Variables globales: curX, curY, nCuadros, dx, dy
  //Variables de trabajo: xMax, xMin, yMax
  //Variables de salida: xMax, xMin, yMax
  //

}

function seleccionar(yClk,xClk) {
  //
  //Descripción: Detecta si ya inició el juego y si el tablero
  //ha sido cargado
  //Llamada desde: seleccionar()
  //Variables globales:
  //Variables de trabajo: 
  //Variables de salida: 
  //

}
//
// keystroke processing
//
retrasoInicial_=200;
retrasoRepite_=20;
//
//Left, Right, Up, Down
//
activeL_=0; timerL_ = null;
activeR_=0; timerR_ = null;
activeU_=0; timerU_ = null;
activeD_=0; timerD_ = null;
activeSp=0; timerSp = null;
//
//Valores ASCII de las teclas
//
LeftNN_ =' 52 ';
RightNN_=' 54 ';
UpNN_   =' 56 53 ';
DownNN_ =' 50 ';
SpaceNN_=' 32 ';
//
//Valores ASCII de las teclas para IE
//
LeftIE_ =' 37 52 100 ';
RightIE_=' 39 54 102 ';
UpIE_   =' 38 56 53 104 101 ';
DownIE_ =' 40 50 98 ';
SpaceIE_=' 32 ';
//
function pulsarTecla(e) {
  //
  //Descripción: 
  //Parámetros: ninguno
  //Variables locales: 
  //Variables globales: 
  //Salida: 
  //
  var KeyNN_=0;
  var KeyIE_=0;
  var evt = e ? e:event;

}

function levantarTecla(e) {
  //
  //Descripción: levantar tecla
  //Parámetros: el objeto de la tecla
  //Variables locales: 
  //Variables globales: 
  //Salida: 
  //
  var KeyNN_=0;
  var KeyIE_=0;
  var evt = e?e:event;
  
}

function slideR_() {
  //
  //Descripción: desliza derecha
  //Parámetros: ninguno
  //Variables locales: 
  //Variables globales: 
  //Salida: 
  //
  
}

function slideD_() {
  //
  //Descripción: desliza abajo
  //Parámetros: ninguno
  //Variables locales: 
  //Variables globales: 
  //Salida: 
  //
  
}
/*****************
  I N I C I O
******************/
function inicio() {
  //
  //Descripción: inicia el juego
  //Parámetros: 
  //Variables locales: 
  //Variables globales: 
  //Salida: 
  //
  //Manejo de eventos
  //
  document.onkeydown = pulsarTecla;
  document.onkeyup = levantarTecla;
  //
  //Limpia variables
  //
  reiniciaJuego();
  //
  top.focus();
}