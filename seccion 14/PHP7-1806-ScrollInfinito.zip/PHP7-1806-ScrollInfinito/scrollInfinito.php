<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Scroll infinito con AJAX y PHP</title>
	<script>
		/*************
		Variables
		**************/
		var productos = document.getElementById("productos");
		var cargarMas = document.getElementById("cargarMas");

		/*************
		Funciones
		**************/
		function cargarMasProductos(){
			
		}

		/*************
		Inicio (TODO)
		**************/
		window.onload = function(){
			cargarMas.addEventListener("click",cargarMasProductos);
			cargarMasProductos();
		}
	</script>
</head>
<body>
	<div id="productos"></div>

	<div id="spinner"><img src="spinner.gif" width="50" height="50"></div>

	<div id="cargar"><button id="cargarMas">Cargar más...</button></div>
</body>
</html>