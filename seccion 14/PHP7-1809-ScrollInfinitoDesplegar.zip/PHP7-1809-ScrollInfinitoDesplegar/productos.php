<?php
/**************
Funciones
***************/
	function solicitudAjax(){
		return isset($_SERVER['HTTP_X_REQUESTED_WITH']) &&
			$_SERVER['HTTP_X_REQUESTED_WITH']=="XMLHttpRequest";
	}
	function leeProductos($pagina){
		$primerProducto = 1;
		$productosPagina = 3;
		$offset = (($pagina-1)*$productosPagina)+1;

		$data = array();
		for ($i=0; $i < $productosPagina; $i++) { 
			$id = $primerProducto - 1 + $offset + $i;
			$producto = [
				'id'=>$id,
				'nombre'=>"Producto #".$id,
				'texto'=>"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent volutpat commodo massa, vitae blandit ligula. Donec ut lobortis ligula, sit amet feugiat est. Aenean et ante in enim pellentesque dapibus. Quisque et sollicitudin sapien, eu auctor arcu. Nullam rutrum eleifend odio vel sagittis. Praesent ut laoreet magna. Donec in ex imperdiet, sodales ipsum eu, iaculis velit. Mauris mollis venenatis massa at varius. Pellentesque rhoncus finibus nisl, nec facilisis augue. Vestibulum euismod eget lorem vitae vestibulum. Integer in consectetur urna. Fusce lobortis lacus sed felis blandit commodo.Maecenas condimentum interdum sapien eu tempus. Cras malesuada augue auctor lectus suscipit, scelerisque pellentesque libero varius. Ut et urna a velit placerat eleifend. Mauris pharetra cursus nibh ac porta. Fusce rutrum felis sit amet tellus volutpat feugiat. Vivamus suscipit vitae neque eu blandit. Quisque lacinia gravida sapien quis pretium. Duis ut lectus nulla."
			];
			$data[] = $producto;
		}
		return $data;
	}
/**************
Inicios
***************/
	if(solicitudAjax()){
		$pagina = isset($_GET['pagina']) ? (int) $_GET['pagina'] : 1;
		$data = leeProductos($pagina);

		foreach ($data as $item) {
			print "<div id='producto-".$item['id']."' class='producto'>";
			print "<h3>".$item['nombre']."</h3>";
			print "<p>".$item['texto']."</p>";
			print "</div>";
		}
	}

?>