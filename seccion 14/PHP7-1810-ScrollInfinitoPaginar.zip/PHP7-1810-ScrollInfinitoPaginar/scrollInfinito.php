<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Scroll infinito con AJAX y PHP</title>
	<style>
		#productos{
			width:700px;
		}
		#spinner{
			display: none;
		}
		.producto{
			border: 1px solid black;
			margin: 10px;
			padding:10px;
		}

	</style>
	<script>
		/*************
		Variables
		**************/
		var productos;
		var cargarMas;

		/*************
		Funciones
		**************/
		function cargarMasProductos(){
			mostrarSpinner();
			ocultarBoton();

			//Recuperar la página
			var pagina = parseInt(cargarMas.getAttribute('data-pag'));
			var siguientePagina = pagina + 1;

			var xhr = new XMLHttpRequest();
			xhr.open("GET","productos.php?pagina="+siguientePagina,true);
			xhr.setRequestHeader("X-Requested-With","XMLHttpRequest");
			xhr.send();
			xhr.onreadystatechange = function(){
				if (xhr.readyState == 4 && xhr.status == 200) {
					var resultado = xhr.responseText;
					
					ocultarSpinner();
					//Actualizar la página
					cargarMas.setAttribute('data-pag',siguientePagina);
					//
					mostrarDatos(productos, resultado);
					//
					mostrarBoton();
				}
			}
		}
		function ocultarSpinner(){
			var spinner = document.getElementById("spinner");
			spinner.style.display = "none";
		}
		function mostrarSpinner(){
			var spinner = document.getElementById("spinner");
			spinner.style.display = "inline";
		}
		function ocultarBoton(){
			cargarMas.style.display = 'none';
		}
		function mostrarBoton(){
			cargarMas.style.display = 'inline';
		}
		function mostrarDatos(div, resultado){
			//console.log(resultado);
			//Creamos una division temporal
			var temp = document.createElement("div");
			temp.innerHTML = resultado;

			//Buscamos los elementos con class
			var class_name = temp.firstElementChild.className;
			var items = temp.getElementsByClassName(class_name);

			//Desplegamos
			var len = items.length;
			for (var i = 0; i < len; i++) {
				div.appendChild(items[0]);
			}
		}

		/*************
		Inicio (TODO)
		**************/
		window.onload = function(){
			productos = document.getElementById("productos");
			cargarMas = document.getElementById("cargarMas");
			cargarMas.addEventListener("click",cargarMasProductos);
			cargarMasProductos();
		}
	</script>
</head>
<body>
	<div id="productos"></div>

	<div id="spinner"><img src="spinner.gif" width="50" height="50"></div>

	<div id="cargar"><button id="cargarMas" data-pag="0">Cargar más...</button></div>
</body>
</html>