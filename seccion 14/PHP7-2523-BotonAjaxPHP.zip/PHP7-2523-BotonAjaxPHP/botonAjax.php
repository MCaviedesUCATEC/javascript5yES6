<!DOCTYPE html>
<html>
<head>
	<title>Botón Ajax</title>
	<meta charset="utf-8">
	<style>
		#productos{
			width:700px;
			margin:0 auto;
		}
		.producto{
			border: 1px solid black;
			margin: 10px;
			padding: 10px;
		}
		button.favorito, button.nofavorito{
			background: #0000ff;
			color:white;
			text-align: center;
			width:100px;
		}
		button.favorito{
			display:inline;
		}
		button.nofavorito{
			display:none;
		}
		button.favorito:hover, button.nofavorito:hover{
			background:#000099;
		}
		.favorito button.favorito{
			display:none;
		}
	</style>
	<script>
	window.onload = function(){
		var botones = document.getElementsByClassName("favorito");
		for (var i = 0; i < botones.length; i++) {
			botones.item(i).addEventListener("click",favorito);
		}
		var botones = document.getElementsByClassName("nofavorito");
		for (var i = 0; i < botones.length; i++) {
			botones.item(i).addEventListener("click",nofavorito);
		}
	}
	/*********************
	   F U N C I O N E S
	**********************/
	function favorito() {
		var producto = this.parentElement;

		var xhr = new XMLHttpRequest();
		xhr.open("POST","favorito.php",true);
		xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
		xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
		xhr.send("id="+producto.id);
		xhr.onreadystatechange = function(){
			if (xhr.readyState == 4 && xhr.status == 200) {
				var r = xhr.responseText;
				if (r=="OK") {
					producto.classList.add("favorito");
				}
			}
		}
	}
	function nofavorito() {
		var producto = this.parentElement;

		var xhr = new XMLHttpRequest();
		xhr.open("POST","nofavorito.php",true);
		xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
		xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
		xhr.send("id="+producto.id);
		xhr.onreadystatechange = function(){
			if (xhr.readyState == 4 && xhr.status == 200) {
				var r = xhr.responseText;
				if (r=="OK") {
					producto.classList.remove("favorito");
				}
			}
		}
	}
	</script>
</head>
<body>
<div id="productos">
	<div id="producto-1" class="producto">
		<h3>Producto 1</h3>
		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
		consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
		cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
		proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
	</p>
	<button class="favorito">Favorito</button>
	<button class="nofavorito">No favorito</button>
	</div>
	<div id="producto-2" class="producto">
		<h3>Producto 2</h3>
		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
		consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
		cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
		proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
	</p>
	<button class="favorito">Favorito</button>
	<button class="nofavorito">No favorito</button>
	</div>
	<div id="producto-3" class="producto">
		<h3>Producto 3</h3>
		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
		consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
		cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
		proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
	</p>
	<button class="favorito">Favorito</button>
	<button class="nofavorito">No favorito</button>
	</div>
</div>
</body>
</html>