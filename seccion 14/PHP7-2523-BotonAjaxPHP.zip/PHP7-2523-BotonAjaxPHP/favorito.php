<?php
session_start();

if(!isset($_SESSION['favoritos'])){ 
	$_SESSION['favoritos'] = [];
}
if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
	$_SERVER['HTTP_X_REQUESTED_WITH']=="XMLHttpRequest") {
	
	$id = isset($_POST["id"]) ? $_POST["id"] : "";
	
	if (preg_match("/producto-(\d+)/", $id, $valores)) {
		$id = $valores[1];

		//Analizamos el arreglo de favoritos
		if (!in_array($id,$_SESSION['favoritos'])) {
			$_SESSION['favoritos'][] = $id
		}
	}
	print "OK";
} else {
	print "ERROR";
}
?>