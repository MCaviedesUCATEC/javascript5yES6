<?php
session_start();

if(!isset($_SESSION['favoritos'])){ 
	$_SESSION['favoritos'] = [];
}
if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
	$_SERVER['HTTP_X_REQUESTED_WITH']=="XMLHttpRequest") {
	
	$id = isset($_POST["id"]) ? $_POST["id"] : "";
	
	if (preg_match("/producto-(\d+)/", $id, $valores)) {
		$id = $valores[1];

		//Analizamos el arreglo de favoritos
		if (in_array($id,$_SESSION['favoritos'])) {
			//Nos indica la posición dentro del arreglo
			$i = array_search($id, $_SESSION['favoritos']);
			//Eliminamos el elemento
			array_splice($_SESSION['favoritos'], $i, 1);
		}
	}
	print "OK";
} else {
	print "ERROR";
}
?>